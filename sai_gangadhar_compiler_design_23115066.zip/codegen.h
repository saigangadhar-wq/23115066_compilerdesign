#ifndef CODEGEN_H
#define CODEGEN_H

#include "parser.h"
#include <string>

std::string generate_three_address_code(const ASTNode& node) {
    return "t1 = " + std::to_string(node.a) + " ^ " + std::to_string(node.b) + "\n" +
           "t2 = t1 ^ " + std::to_string(node.c);
}

std::string generate_assembly(const ASTNode& node) {
    return "MOV R1, #" + std::to_string(node.a) + "\n" +
           "XOR R1, #" + std::to_string(node.b) + "\n" +
           "XOR R1, #" + std::to_string(node.c);
}

int execute(const ASTNode& node) {
    return node.a ^ node.b ^ node.c;
}

#endif