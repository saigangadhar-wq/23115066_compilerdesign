#ifndef PARSER_H
#define PARSER_H

#include <vector>

struct ASTNode {
    int a, b, c;
};

ASTNode parse(const std::vector<int>& tokens) {
    if (tokens.size() != 3) {
        throw std::runtime_error("Exactly three integers required.");
    }
    return {tokens[0], tokens[1], tokens[2]};
}

#endif