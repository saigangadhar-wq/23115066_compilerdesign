#ifndef LEXER_H
#define LEXER_H

#include <vector>
#include <string>
#include <sstream>

std::vector<int> tokenize(const std::string& input) {
    std::vector<int> tokens;
    std::istringstream stream(input);
    int number;
    while (stream >> number) {
        tokens.push_back(number);
    }
    return tokens;
}

#endif