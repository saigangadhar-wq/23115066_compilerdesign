#ifndef OPTIMIZER_H
#define OPTIMIZER_H

#include "parser.h"

ASTNode optimize(const ASTNode& node) {
    // No real optimization for XOR, but could be extended.
    return node;
}

#endif