#include <iostream>
#include "lexer.h"
#include "parser.h"
#include "optimizer.h"
#include "codegen.h"

int main() {
    std::string input;
    std::cout << "Enter three integers separated by space: ";
    std::getline(std::cin, input);

    auto tokens = tokenize(input);
    auto ast = parse(tokens);
    auto optimized_ast = optimize(ast);

    std::string tac = generate_three_address_code(optimized_ast);
    std::string assembly = generate_assembly(optimized_ast);
    int result = execute(optimized_ast);

    std::cout << "\nThree Address Code:\n" << tac;
    std::cout << "\nAssembly Code:\n" << assembly;
    std::cout << "\nOptimized XOR result: " << result << std::endl;
    return 0;
}